import json
import os

def generate_wget_script(json_file, shell_script):
    try:
        # Read the JSON file
        with open(json_file, 'r') as file:
            urls = json.load(file)

        if not isinstance(urls, list):
            raise ValueError("The JSON file does not contain an array of URLs.")

        # Generate the shell script content
        script_content = "#!/bin/bash\n\n"
        for url in urls:
            script_content += f"wget \"{url}\"\n"

        # Write the shell script to a file
        with open(shell_script, 'w') as file:
            file.write(script_content)

        # Make the shell script executable
        os.chmod(shell_script, 0o755)

        print(f"Shell script {shell_script} generated successfully.")

    except FileNotFoundError:
        print(f"File {json_file} not found.")
    except json.JSONDecodeError:
        print("Invalid JSON format.")
    except Exception as e:
        print(f"An error occurred: {e}")

# File paths
json_file = 'urls.json'
shell_script = 'download_files.sh'

# Generate the shell script
generate_wget_script(json_file, shell_script)
